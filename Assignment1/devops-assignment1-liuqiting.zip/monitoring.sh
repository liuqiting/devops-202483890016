#!/usr/bin/env bash
# Lightweight EC2 health report; intended for Amazon Linux 2023.
set -u

metadata() {
    local path="$1"
    curl --fail --silent --show-error --max-time 3 \
        -H "X-aws-ec2-metadata-token: ${TOKEN}" \
        "http://169.254.169.254/latest/meta-data/${path}" 2>/dev/null || printf 'unavailable'
}

TOKEN=$(curl --fail --silent --show-error --max-time 3 -X PUT \
    "http://169.254.169.254/latest/api/token" \
    -H "X-aws-ec2-metadata-token-ttl-seconds: 300" 2>/dev/null) || {
    echo "ERROR: could not obtain IMDSv2 token" >&2
    exit 1
}

echo "Instance ID: $(metadata instance-id)"
echo "Private IP: $(metadata local-ipv4)"
echo "Instance type: $(metadata instance-type)"
echo "Availability zone: $(metadata placement/availability-zone)"
if command -v free >/dev/null 2>&1; then
    free -m | awk 'NR==2 {printf "Memory utilisation: %.2f%%\n", $3*100/$2}'
fi
echo "Load average: $(cut -d' ' -f1-3 /proc/loadavg 2>/dev/null || echo unavailable)"
echo "Process count: $(ps -e --no-headers 2>/dev/null | wc -l | tr -d ' ')"
if systemctl is-active --quiet httpd; then
    echo "Web server: running"
else
    echo "Web server: NOT running"
    exit 2
fi
if command -v curl >/dev/null 2>&1 && curl --fail --silent --max-time 5 http://localhost/ >/dev/null; then
    echo "HTTP localhost check: passed"
else
    echo "HTTP localhost check: failed"
    exit 3
fi
