#!/usr/bin/env python3
"""Automate the DevOps Assignment 1 AWS demo.

Requires boto3 and requests, plus AWS credentials configured outside this file.
The account must already have a usable EC2 key pair and security group.
"""

from __future__ import annotations

import argparse
import json
import logging
import random
import re
import string
import subprocess
import sys
import time
import webbrowser
from pathlib import Path

import boto3
import requests
from botocore.exceptions import BotoCoreError, ClientError, WaiterError

LOG = logging.getLogger("devops_ass1")
IMAGE_URL = "https://placehold.co/600x400.jpg"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--name", default="cbinbin", help="lowercase name suffix for S3 bucket and URL file")
    parser.add_argument("--key-name", required=True, help="existing EC2 key pair name (without .pem)")
    parser.add_argument("--key-file", required=True, type=Path, help="local SSH private key PEM file")
    parser.add_argument("--security-group-id", required=True, help="existing security group allowing HTTP and SSH")
    parser.add_argument("--subnet-id", help="subnet in the same VPC as the security group")
    parser.add_argument("--region", default="us-east-1")
    parser.add_argument("--instance-type", default="t3.nano")
    parser.add_argument("--extra-wait", type=int, default=90, help="seconds for cloud-init/web server setup")
    parser.add_argument("--no-browser", action="store_true")
    return parser.parse_args()


def latest_amazon_linux_2023(ec2) -> str:
    images = ec2.describe_images(
        Owners=["amazon"],
        Filters=[{"Name": "name", "Values": ["al2023-ami-2023.*-x86_64"]},
                 {"Name": "state", "Values": ["available"]},
                 {"Name": "architecture", "Values": ["x86_64"]}],
    )["Images"]
    if not images:
        raise RuntimeError("No available Amazon Linux 2023 x86_64 AMI found in this region")
    images.sort(key=lambda image: image["CreationDate"], reverse=True)
    return images[0]["ImageId"]


def user_data() -> str:
    return r'''#!/bin/bash
set -euo pipefail
if [ ! -e /swap-ass1 ]; then
    install -m 600 /dev/null /swap-ass1
    dd if=/dev/zero of=/swap-ass1 bs=1M count=1024 status=none
    mkswap /swap-ass1
fi
if ! swapon --show=NAME --noheadings | grep -Fxq /swap-ass1; then
    swapon /swap-ass1
fi
dnf -y update
dnf -y install httpd
systemctl enable --now httpd
TOKEN=$(curl --fail --silent --show-error -X PUT "http://169.254.169.254/latest/api/token" -H "X-aws-ec2-metadata-token-ttl-seconds: 21600")
md() { curl --fail --silent --show-error -H "X-aws-ec2-metadata-token: $TOKEN" "http://169.254.169.254/latest/meta-data/$1"; }
cat > /var/www/html/index.html <<EOF
<!doctype html><html><head><meta charset="utf-8"><title>DevOps Assignment 1</title></head>
<body><h1>Amazon Linux web server</h1><ul>
<li>Instance ID: $(md instance-id)</li><li>Private IP: $(md local-ipv4)</li>
<li>Instance type: $(md instance-type)</li><li>Availability zone: $(md placement/availability-zone)</li>
</ul><p>Automated deployment for DevOps Assignment 1.</p></body></html>
EOF
'''


def run_checked(command: list[str], description: str) -> None:
    LOG.info("%s: %s", description, " ".join(command))
    result = subprocess.run(command, text=True, capture_output=True, check=False)
    if result.stdout:
        LOG.info("%s", result.stdout.rstrip())
    if result.returncode:
        raise RuntimeError(f"{description} failed ({result.returncode}): {result.stderr.strip()}")


def main() -> int:
    args = parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    if not re.fullmatch(r"[a-z0-9-]{2,30}", args.name):
        LOG.error("--name must contain only lowercase letters, digits, and hyphens")
        return 2
    if not args.key_file.is_file():
        LOG.error("SSH key file does not exist: %s", args.key_file)
        return 2
    session = boto3.Session(region_name=args.region)
    ec2 = session.resource("ec2")
    ec2_client = session.client("ec2")
    s3 = session.resource("s3")
    s3_client = session.client("s3")
    created_instance = None
    bucket_name = None
    try:
        ami_id = latest_amazon_linux_2023(ec2_client)
        LOG.info("Launching %s from latest Amazon Linux 2023 AMI %s", args.instance_type, ami_id)
        network_interfaces = [{
            "DeviceIndex": 0,
            "SubnetId": args.subnet_id,
            "Groups": [args.security_group_id],
            "AssociatePublicIpAddress": True,
        }] if args.subnet_id else None
        launch_options = {
            "ImageId": ami_id, "InstanceType": args.instance_type, "MinCount": 1, "MaxCount": 1,
            "KeyName": args.key_name, "UserData": user_data(),
            "TagSpecifications": [{"ResourceType": "instance", "Tags": [
                {"Key": "Name", "Value": "DevOps Assignment 1"},
                {"Key": "Project", "Value": "DevOpsAssignment1"}]}],
        }
        if network_interfaces:
            launch_options["NetworkInterfaces"] = network_interfaces
        else:
            launch_options["SecurityGroupIds"] = [args.security_group_id]
        instances = ec2.create_instances(
            **launch_options,
        )
        created_instance = instances[0]
        LOG.info("Created instance %s; waiting for running state", created_instance.id)
        created_instance.wait_until_running()
        created_instance.reload()
        if not created_instance.public_ip_address:
            raise RuntimeError("Instance has no public IP; check subnet auto-assign public IPv4 setting")
        time.sleep(max(0, args.extra_wait))
        instance_url = f"http://{created_instance.public_ip_address}/"

        suffix = "".join(random.choices(string.ascii_lowercase + string.digits, k=6))
        bucket_name = f"{suffix}-{args.name}"
        LOG.info("Creating S3 website bucket %s", bucket_name)
        s3.create_bucket(Bucket=bucket_name)
        s3_client.delete_public_access_block(Bucket=bucket_name)
        policy = {"Version": "2012-10-17", "Statement": [{"Sid": "PublicReadGetObject", "Effect": "Allow",
                  "Principal": "*", "Action": ["s3:GetObject"], "Resource": f"arn:aws:s3:::{bucket_name}/*"}]}
        s3.Bucket(bucket_name).Policy().put(Policy=json.dumps(policy))

        image_path = Path("logo.jpg")
        response = requests.get(IMAGE_URL, timeout=30)
        response.raise_for_status()
        image_path.write_bytes(response.content)
        s3.Bucket(bucket_name).upload_file(str(image_path), "logo.jpg", ExtraArgs={"ContentType": "image/jpeg"})
        html = ("<!doctype html><html><head><meta charset=\"utf-8\"><title>DevOps S3 website</title></head>"
                "<body><h1>DevOps Assignment 1</h1><img src=\"logo.jpg\" alt=\"Assignment logo\"></body></html>")
        s3.Object(bucket_name, "index.html").put(Body=html.encode("utf-8"), ContentType="text/html; charset=utf-8")
        s3.BucketWebsite(bucket_name).put(WebsiteConfiguration={"IndexDocument": {"Suffix": "index.html"},
                                                                  "ErrorDocument": {"Key": "index.html"}})
        website_url = f"http://{bucket_name}.s3-website-{args.region}.amazonaws.com/"
        host = created_instance.public_ip_address
        ssh_base = ["ssh", "-o", "StrictHostKeyChecking=no", "-i", str(args.key_file)]
        scp_cmd = ["scp", "-o", "StrictHostKeyChecking=no", "-i", str(args.key_file),
                   str(Path(__file__).with_name("monitoring.sh")), f"ec2-user@{host}:monitoring.sh"]
        run_checked(scp_cmd, "Copy monitoring script")
        run_checked(ssh_base + [f"ec2-user@{host}", "chmod 700 monitoring.sh && ./monitoring.sh"], "Run remote monitoring")

        url_file = Path(f"{args.name}-websites.txt")
        url_file.write_text(f"EC2 website: {instance_url}\nS3 website: {website_url}\n", encoding="utf-8")
        LOG.info("Website URLs saved to %s", url_file.resolve())
        if not args.no_browser:
            webbrowser.open(instance_url)
            webbrowser.open(website_url)
        LOG.info("Deployment complete. Instance ID: %s; bucket: %s", created_instance.id, bucket_name)
        return 0
    except (BotoCoreError, ClientError, WaiterError, requests.RequestException, OSError, RuntimeError) as exc:
        LOG.exception("Deployment failed: %s", exc)
        if created_instance is not None:
            LOG.error("Instance %s may still be running; inspect AWS and terminate it if this run is unwanted", created_instance.id)
        if bucket_name:
            LOG.error("Bucket %s may need manual cleanup if deployment failed partway through", bucket_name)
        return 1


if __name__ == "__main__":
    sys.exit(main())
