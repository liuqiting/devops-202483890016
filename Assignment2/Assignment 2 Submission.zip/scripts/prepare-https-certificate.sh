#!/bin/bash
set -euo pipefail

# Generate the self-signed certificate for ACM import.
umask 077
mkdir -p "$HOME/a2-https"
cd "$HOME/a2-https"
if [[ -e a2-alb.key || -e a2-alb.crt ]]; then
  printf 'Certificate or private key already exists in %s\n' "$PWD" >&2
  exit 1
fi

ALB_HOST='a2-alb-1424166438.us-east-1.elb.amazonaws.com'
openssl req -x509 -newkey rsa:2048 -sha256 -days 30 -nodes \
  -keyout a2-alb.key -out a2-alb.crt \
  -subj "/CN=$ALB_HOST" \
  -addext "subjectAltName=DNS:$ALB_HOST"

openssl x509 -in a2-alb.crt -noout -subject -ext subjectAltName
