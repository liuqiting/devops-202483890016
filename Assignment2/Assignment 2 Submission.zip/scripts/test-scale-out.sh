#!/bin/bash
ALB='http://a2-alb-1424166438.us-east-1.elb.amazonaws.com'
RUN="a2-$(date +%s)"

for i in $(seq 1 100); do
  curl -fsS --max-time 3 "$ALB/?test=$RUN-$i" || break
done | sort | uniq -c

printf 'Test batch: %s\n' "$RUN"
