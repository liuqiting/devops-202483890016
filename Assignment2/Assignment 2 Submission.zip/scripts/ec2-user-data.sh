#!/bin/bash
set -euo pipefail

dnf install -y httpd cronie
if ! command -v aws >/dev/null 2>&1; then
  dnf install -y awscli2
fi

TOKEN=$(curl -fsS --max-time 5 -X PUT \
  -H 'X-aws-ec2-metadata-token-ttl-seconds: 60' \
  http://169.254.169.254/latest/api/token)
INSTANCE_ID=$(curl -fsS --max-time 5 \
  -H "X-aws-ec2-metadata-token: $TOKEN" \
  http://169.254.169.254/latest/meta-data/instance-id)

printf '<h1>Assignment 2 Web App</h1><p>Instance: %s</p>\n' \
  "$INSTANCE_ID" > /var/www/html/index.html
systemctl enable --now httpd

cat > /usr/local/bin/a2-memory-metric <<'EOF'
#!/bin/bash
set -euo pipefail
export PATH=/usr/local/bin:/usr/bin:/bin

INSTANCE_ID=$(cat /etc/a2-instance-id)
USED_PERCENT=$(free -m | awk '/^Mem:/ {printf "%.2f", ($2-$7)*100/$2}')

aws cloudwatch put-metric-data \
  --region us-east-1 \
  --namespace Custom \
  --metric-name memory-usage \
  --dimensions "Instance=$INSTANCE_ID" \
  --unit Percent \
  --value "$USED_PERCENT"
EOF

printf '%s\n' "$INSTANCE_ID" > /etc/a2-instance-id
chmod 755 /usr/local/bin/a2-memory-metric
printf '%s\n' \
  '* * * * * root /usr/local/bin/a2-memory-metric >> /var/log/a2-metrics.log 2>&1' \
  > /etc/cron.d/a2-memory-metric
systemctl enable --now crond
