#!/bin/bash
set -euo pipefail

# Run from an IP allowed by the load balancer security group's HTTPS rule.
curl -4i --connect-timeout 5 --max-time 15 \
  --cacert "$HOME/a2-https/a2-alb.crt" \
  https://a2-alb-1424166438.us-east-1.elb.amazonaws.com/
