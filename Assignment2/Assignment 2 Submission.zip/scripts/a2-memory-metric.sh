#!/bin/bash
set -euo pipefail
export PATH=/usr/local/bin:/usr/bin:/bin

INSTANCE_ID=$(cat /etc/a2-instance-id)
USED_PERCENT=$(free -m | awk '/^Mem:/ {printf "%.2f", ($2-$7)*100/$2}')

aws cloudwatch put-metric-data \
  --region us-east-1 \
  --namespace Custom \
  --metric-name memory-usage \
  --dimensions "Instance=$INSTANCE_ID" \
  --unit Percent \
  --value "$USED_PERCENT"
