#!/bin/bash
ALB='http://a2-alb-1424166438.us-east-1.elb.amazonaws.com'

for i in $(seq 1 16); do
  curl -fsS --max-time 5 -o /dev/null "$ALB/?test=a2-low-$i" || break
  printf 'Sent low-traffic request %s\n' "$i"
  sleep 16
done
